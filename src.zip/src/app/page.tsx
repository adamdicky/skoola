'use client'; // only if you're using App Router

import { useState } from 'react';
import Image from 'next/image';

export default function SchoolPage() {

  return (
    <div className="bg-gradient-to-b from-[#B2B8EE] to-[#F3F4FE]">

    </div>
  );
}
